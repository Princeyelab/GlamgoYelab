import { Stack } from 'expo-router';

export default function AuthLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="login" />
      <Stack.Screen name="signup-client" />
      <Stack.Screen name="signup-provider" />
      <Stack.Screen name="forgot-password" />
    </Stack>
  );
}
