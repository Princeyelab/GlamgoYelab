/**
 * Services GlamGo - Synchronise avec la web app
 * 33 services avec images locales
 * FORMAT CONFORME A ServiceCard.tsx
 */

import { Service } from '../../types/service';

// URL de base pour les images (backend GlamGo)
const BACKEND_URL = 'https://glamgo-api.fly.dev';
const IMAGE_BASE_URL = `${BACKEND_URL}/images/services`;

// Images Unsplash pour services sans photo backend
const CHEF_2P_IMAGE = 'https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=400&h=300&fit=crop';
const CHEF_4P_IMAGE = 'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?w=400&h=300&fit=crop';
const CHEF_8P_IMAGE = 'https://images.unsplash.com/photo-1581299894007-aaa50297cf16?w=400&h=300&fit=crop';

// Mapping des images par service (identique a web app serviceImages.js)
export const SERVICE_IMAGES: Record<string, string> = {
  // Chef a domicile
  'chef-domicile': `${IMAGE_BASE_URL}/chef-domicile.jpg`,
  'chef-domicile-2-personnes': CHEF_2P_IMAGE,
  'chef-domicile-4-personnes': CHEF_4P_IMAGE,
  'chef-domicile-8-personnes': CHEF_8P_IMAGE,

  // Coach & Sport
  'coach-sportif': `${IMAGE_BASE_URL}/coach-sportif.jpg`,

  // Coiffure
  'coiffure-classique': `${IMAGE_BASE_URL}/coiffure-classique.jpg`,
  'coiffure-express': `${IMAGE_BASE_URL}/coiffure-express.jpg`,
  'coiffure-homme-premium': `${IMAGE_BASE_URL}/coiffure-homme-premium.jpg`,
  'coiffure-mariage-evenement': `${IMAGE_BASE_URL}/coiffure-mariage-evenement.jpg`,
  'coiffure-homme-simple': `${IMAGE_BASE_URL}/coiffure-homme-simple.jpg`,

  // Danse
  'danse-orientale': `${IMAGE_BASE_URL}/danse-orientale.jpg`,

  // Animaux
  'gardiennage-animaux': `${IMAGE_BASE_URL}/gardiennage-animaux.jpg`,
  'promenade-animaux': `${IMAGE_BASE_URL}/promenade-animaux.jpg`,

  // Bien-etre
  'hammam-gommage': `${IMAGE_BASE_URL}/hammam-gommage.jpg`,
  'massage-relaxant': `${IMAGE_BASE_URL}/massage-relaxant.jpg`,
  'soin-premium-argan': `${IMAGE_BASE_URL}/soin-premium-argan.jpg`,
  'yoga': `${IMAGE_BASE_URL}/yoga.jpg`,

  // Maison
  'jardinage': `${IMAGE_BASE_URL}/jardinage.jpg`,
  'menage': `${IMAGE_BASE_URL}/menage.jpg`,
  'bricolage': `${IMAGE_BASE_URL}/bricolage.jpg`,

  // Auto
  'lavage-complet': `${IMAGE_BASE_URL}/nettoyage-auto-complet.jpg`,
  'lavage-exterieur': `${IMAGE_BASE_URL}/nettoyage-auto-externe.jpg`,
  'lavage-interieur': `${IMAGE_BASE_URL}/nettoyage-auto-interne.jpg`,

  // Barbe
  'pack-coiffure-barbe': `${IMAGE_BASE_URL}/pack-coiffure-barbe.jpg`,
  'taille-barbe': `${IMAGE_BASE_URL}/taille-barbe.jpg`,

  // Epilation Smooth
  'smooth-femme': `${IMAGE_BASE_URL}/smooth-femme.jpg`,
  'smooth-femme-full': `${IMAGE_BASE_URL}/smooth-femme-full.jpg`,
  'smooth-homme': `${IMAGE_BASE_URL}/smooth-homme.jpg`,
  'smooth-homme-full': `${IMAGE_BASE_URL}/smooth-homme-full.jpg`,

  // Hijama
  'hijama': `${IMAGE_BASE_URL}/hijama.jpg`,

  // Manucure
  'manucure-classique': `${IMAGE_BASE_URL}/manucure-classique.jpg`,
  'manucure-gel': `${IMAGE_BASE_URL}/manucure-gel.jpg`,

  // Maquillage
  'maquillage-jour': `${IMAGE_BASE_URL}/maquillage-jour.jpg`,
  'maquillage-mariage': `${IMAGE_BASE_URL}/maquillage-mariage.jpg`,
};

/**
 * 33 services reels - FORMAT CONFORME A ServiceCard
 * Utilise: title, images[], reviews_count, duration_minutes
 */
export const SERVICES: Service[] = [
  // === MAISON (category_id: 1) ===
  {
    id: 1,
    title: 'Menage classique',
    slug: 'menage-classique',
    description: 'Nettoyage standard de votre logement avec produits fournis. Inclut aspirateur, serpilliere et depoussierage.',
    category_id: 1,
    category: { id: 1, name: 'Maison', color: '#3B82F6' },
    price: 100,
    currency: 'MAD',
    duration_minutes: 60,
    images: [SERVICE_IMAGES['menage']],
    rating: 4.8,
    reviews_count: 156,
    provider: { id: 1, name: 'Fatima B.' },
    status: 'active',
  },
  {
    id: 2,
    title: 'Jardinage',
    slug: 'jardinage',
    description: 'Entretien de vos espaces verts : tonte pelouse, taille haies, desherbage et plantation de fleurs.',
    category_id: 1,
    category: { id: 1, name: 'Maison', color: '#3B82F6' },
    price: 250,
    currency: 'MAD',
    duration_minutes: 60,
    images: [SERVICE_IMAGES['jardinage']],
    rating: 4.7,
    reviews_count: 89,
    provider: { id: 2, name: 'Ahmed M.' },
    status: 'active',
  },
  {
    id: 3,
    title: 'Bricolage',
    slug: 'bricolage',
    description: 'Petits travaux et reparations : montage meubles, percage, fixations murales et petite plomberie.',
    category_id: 1,
    category: { id: 1, name: 'Maison', color: '#3B82F6' },
    price: 200,
    currency: 'MAD',
    duration_minutes: 60,
    images: [SERVICE_IMAGES['bricolage']],
    rating: 4.6,
    reviews_count: 112,
    provider: { id: 3, name: 'Youssef K.' },
    status: 'active',
  },
  {
    id: 4,
    title: 'Chef a domicile',
    slug: 'chef-domicile',
    description: 'Chef professionnel prepare vos repas a domicile. Menu personnalise selon vos gouts. A partir de 2 personnes.',
    category_id: 1,
    category: { id: 1, name: 'Maison', color: '#3B82F6' },
    price: 500, // Prix affiche = prix minimum (2 personnes)
    price_per_person: 250, // Prix par personne
    min_guests: 2,
    max_guests: 12,
    service_type: 'chef',
    currency: 'MAD',
    duration_minutes: 120,
    images: [SERVICE_IMAGES['chef-domicile']],
    rating: 4.9,
    reviews_count: 146,
    provider: { id: 4, name: 'Karim L.' },
    status: 'active',
  },

  // === BEAUTE (category_id: 2) ===
  {
    id: 7,
    title: 'Coiffure Homme Simple',
    slug: 'coiffure-homme-simple',
    description: 'Coupe de cheveux classique pour homme. Shampooing et coiffage inclus.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 135,
    currency: 'MAD',
    duration_minutes: 30,
    images: [SERVICE_IMAGES['coiffure-homme-simple']],
    rating: 4.7,
    reviews_count: 234,
    provider: { id: 5, name: 'Hassan R.' },
    status: 'active',
  },
  {
    id: 8,
    title: 'Coiffure Homme Premium',
    slug: 'coiffure-homme-premium',
    description: 'Coupe tendance et stylee avec conseil personnalise. Finitions soignees au rasoir.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 175,
    currency: 'MAD',
    duration_minutes: 40,
    images: [SERVICE_IMAGES['coiffure-homme-premium']],
    rating: 4.9,
    reviews_count: 189,
    provider: { id: 5, name: 'Hassan R.' },
    is_featured: true,
    status: 'active',
  },
  {
    id: 9,
    title: 'Taille de Barbe',
    slug: 'taille-barbe',
    description: 'Entretien et sculpture de barbe. Contours nets au rasoir et soin hydratant.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 100,
    currency: 'MAD',
    duration_minutes: 20,
    images: [SERVICE_IMAGES['taille-barbe']],
    rating: 4.8,
    reviews_count: 156,
    provider: { id: 5, name: 'Hassan R.' },
    status: 'active',
  },
  {
    id: 10,
    title: 'Pack Coiffure + Barbe',
    slug: 'pack-coiffure-barbe',
    description: 'Combo complet : coupe cheveux et entretien barbe. Le meilleur rapport qualite-prix.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 260,
    currency: 'MAD',
    duration_minutes: 60,
    images: [SERVICE_IMAGES['pack-coiffure-barbe']],
    rating: 4.9,
    reviews_count: 145,
    provider: { id: 5, name: 'Hassan R.' },
    is_featured: true,
    status: 'active',
  },
  {
    id: 11,
    title: 'Coiffure Classique',
    slug: 'coiffure-classique',
    description: 'Coupe et brushing femme. Shampooing, soin et coiffage adaptes a votre type de cheveux.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 225,
    currency: 'MAD',
    duration_minutes: 45,
    images: [SERVICE_IMAGES['coiffure-classique']],
    rating: 4.8,
    reviews_count: 198,
    provider: { id: 6, name: 'Samira N.' },
    status: 'active',
  },
  {
    id: 12,
    title: 'Coiffure Express',
    slug: 'coiffure-express',
    description: 'Coupe rapide pour femme. Ideal quand vous etes pressee mais souhaitez un resultat impeccable.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 150,
    currency: 'MAD',
    duration_minutes: 30,
    images: [SERVICE_IMAGES['coiffure-express']],
    rating: 4.6,
    reviews_count: 167,
    provider: { id: 6, name: 'Samira N.' },
    status: 'active',
  },
  {
    id: 13,
    title: 'Coiffure Mariage',
    slug: 'coiffure-mariage-evenement',
    description: 'Coiffure mariee avec seance d\'essai incluse. Chignon, tresses ou coiffure sur mesure pour votre grand jour.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 1000,
    currency: 'MAD',
    duration_minutes: 120,
    images: [SERVICE_IMAGES['coiffure-mariage-evenement']],
    rating: 4.9,
    reviews_count: 78,
    provider: { id: 6, name: 'Samira N.' },
    isNew: true,
    status: 'active',
  },

  // === VOITURE (category_id: 3) ===
  {
    id: 14,
    title: 'Lavage Exterieur',
    slug: 'lavage-exterieur',
    description: 'Lavage exterieur complet de votre vehicule. Carrosserie, vitres et jantes impeccables.',
    category_id: 3,
    category: { id: 3, name: 'Voiture', color: '#6B7280' },
    price: 150,
    currency: 'MAD',
    duration_minutes: 45,
    images: [SERVICE_IMAGES['lavage-exterieur']],
    rating: 4.5,
    reviews_count: 234,
    provider: { id: 7, name: 'Omar A.' },
    status: 'active',
  },
  {
    id: 15,
    title: 'Lavage Interieur',
    slug: 'lavage-interieur',
    description: 'Nettoyage interieur approfondi : sieges, moquettes, tableaux de bord et vitres interieures.',
    category_id: 3,
    category: { id: 3, name: 'Voiture', color: '#6B7280' },
    price: 185,
    currency: 'MAD',
    duration_minutes: 60,
    images: [SERVICE_IMAGES['lavage-interieur']],
    rating: 4.6,
    reviews_count: 189,
    provider: { id: 7, name: 'Omar A.' },
    status: 'active',
  },
  {
    id: 16,
    title: 'Lavage Complet',
    slug: 'lavage-complet',
    description: 'Nettoyage complet interieur et exterieur. Votre vehicule comme neuf, a domicile.',
    category_id: 3,
    category: { id: 3, name: 'Voiture', color: '#6B7280' },
    price: 325,
    currency: 'MAD',
    duration_minutes: 90,
    images: [SERVICE_IMAGES['lavage-complet']],
    rating: 4.8,
    reviews_count: 156,
    provider: { id: 7, name: 'Omar A.' },
    is_featured: true,
    status: 'active',
  },

  // === BIEN-ETRE (category_id: 4) ===
  {
    id: 17,
    title: 'Massage Relaxant',
    slug: 'massage-relaxant',
    description: 'Massage aux huiles orientales pour une detente totale. Techniques marocaines traditionnelles.',
    category_id: 4,
    category: { id: 4, name: 'Bien-etre', color: '#2A9D8F' },
    price: 400,
    currency: 'MAD',
    duration_minutes: 60,
    images: [SERVICE_IMAGES['massage-relaxant']],
    rating: 4.9,
    reviews_count: 267,
    provider: { id: 8, name: 'Nadia T.' },
    is_featured: true,
    status: 'active',
  },
  {
    id: 18,
    title: 'Hammam & Gommage',
    slug: 'hammam-gommage',
    description: 'Ritual hammam traditionnel avec gommage au savon noir et ghassoul. Peau douce garantie.',
    category_id: 4,
    category: { id: 4, name: 'Bien-etre', color: '#2A9D8F' },
    price: 350,
    currency: 'MAD',
    duration_minutes: 90,
    images: [SERVICE_IMAGES['hammam-gommage']],
    rating: 4.8,
    reviews_count: 189,
    provider: { id: 8, name: 'Nadia T.' },
    status: 'active',
  },
  {
    id: 19,
    title: 'Soin Premium Argan',
    slug: 'soin-premium-argan',
    description: 'Soin visage et corps a l\'huile d\'argan bio du Maroc. Hydratation et nutrition intense.',
    category_id: 4,
    category: { id: 4, name: 'Bien-etre', color: '#2A9D8F' },
    price: 500,
    currency: 'MAD',
    duration_minutes: 75,
    images: [SERVICE_IMAGES['soin-premium-argan']],
    rating: 4.9,
    reviews_count: 134,
    provider: { id: 8, name: 'Nadia T.' },
    isNew: true,
    status: 'active',
  },
  {
    id: 20,
    title: 'Yoga',
    slug: 'yoga',
    description: 'Seance de yoga personnalisee a domicile. Tous niveaux, debutant a avance.',
    category_id: 4,
    category: { id: 4, name: 'Bien-etre', color: '#2A9D8F' },
    price: 250,
    currency: 'MAD',
    duration_minutes: 60,
    images: [SERVICE_IMAGES['yoga']],
    rating: 4.7,
    reviews_count: 98,
    provider: { id: 9, name: 'Layla M.' },
    status: 'active',
  },
  {
    id: 21,
    title: 'Coach Sportif',
    slug: 'coach-sportif',
    description: 'Entrainement personnalise selon vos objectifs : perte de poids, musculation ou remise en forme. Minimum 4 seances.',
    category_id: 4,
    category: { id: 4, name: 'Bien-etre', color: '#2A9D8F' },
    price: 700, // Prix du pack minimum (Decouverte - 4 seances)
    service_type: 'coach',
    packs: [
      { id: 'decouverte', name: 'Decouverte', sessions: 4, price: 700, pricePerSession: 175 },
      { id: 'classique', name: 'Classique', sessions: 8, price: 1200, pricePerSession: 150, discount: 17, popular: true },
      { id: 'intensif', name: 'Intensif', sessions: 12, price: 1500, pricePerSession: 125, discount: 29 },
    ],
    currency: 'MAD',
    duration_minutes: 60,
    images: [SERVICE_IMAGES['coach-sportif']],
    rating: 4.8,
    reviews_count: 112,
    provider: { id: 10, name: 'Mehdi S.' },
    status: 'active',
  },
  {
    id: 22,
    title: 'Danse Orientale',
    slug: 'danse-orientale',
    description: 'Cours de danse orientale pour debutants ou confirmes. Apprenez les mouvements traditionnels.',
    category_id: 4,
    category: { id: 4, name: 'Bien-etre', color: '#2A9D8F' },
    price: 300,
    currency: 'MAD',
    duration_minutes: 60,
    images: [SERVICE_IMAGES['danse-orientale']],
    rating: 4.6,
    reviews_count: 67,
    provider: { id: 11, name: 'Amina K.' },
    status: 'active',
  },

  // === ANIMAUX (category_id: 5) ===
  {
    id: 23,
    title: 'Gardiennage Animaux',
    slug: 'gardiennage-animaux',
    description: 'Garde de vos animaux a domicile par un professionnel. Nourriture, jeux et soins inclus.',
    category_id: 5,
    category: { id: 5, name: 'Animaux', color: '#F59E0B' },
    price: 200,
    currency: 'MAD',
    duration_minutes: 1440, // 24h
    images: [SERVICE_IMAGES['gardiennage-animaux']],
    rating: 4.7,
    reviews_count: 89,
    provider: { id: 12, name: 'Sara B.' },
    status: 'active',
  },
  {
    id: 24,
    title: 'Promenade Animaux',
    slug: 'promenade-animaux',
    description: 'Balade quotidienne pour votre chien. Exercice et socialisation avec d\'autres chiens.',
    category_id: 5,
    category: { id: 5, name: 'Animaux', color: '#F59E0B' },
    price: 115,
    currency: 'MAD',
    duration_minutes: 30,
    images: [SERVICE_IMAGES['promenade-animaux']],
    rating: 4.8,
    reviews_count: 156,
    provider: { id: 12, name: 'Sara B.' },
    status: 'active',
  },

  // === EPILATION SMOOTH (category_id: 2 - Beaute) ===
  {
    id: 25,
    title: 'Smooth Femme',
    slug: 'smooth-femme',
    description: 'Epilation zones classiques femme : jambes, aisselles et maillot. Cire chaude ou tiede.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 200,
    currency: 'MAD',
    duration_minutes: 45,
    images: [SERVICE_IMAGES['smooth-femme']],
    rating: 4.7,
    reviews_count: 89,
    provider: { id: 13, name: 'Leila K.' },
    status: 'active',
  },
  {
    id: 26,
    title: 'Smooth Femme Full',
    slug: 'smooth-femme-full',
    description: 'Epilation corps entier femme : jambes, bras, aisselles, maillot et visage. Resultat longue duree.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 450,
    currency: 'MAD',
    duration_minutes: 90,
    images: [SERVICE_IMAGES['smooth-femme-full']],
    rating: 4.9,
    reviews_count: 67,
    provider: { id: 13, name: 'Leila K.' },
    is_featured: true,
    status: 'active',
  },
  {
    id: 27,
    title: 'Smooth Homme',
    slug: 'smooth-homme',
    description: 'Epilation zones classiques homme : torse, dos ou epaules. Technique douce et efficace.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 250,
    currency: 'MAD',
    duration_minutes: 45,
    images: [SERVICE_IMAGES['smooth-homme']],
    rating: 4.6,
    reviews_count: 56,
    provider: { id: 14, name: 'Rachid M.' },
    status: 'active',
  },
  {
    id: 28,
    title: 'Smooth Homme Full',
    slug: 'smooth-homme-full',
    description: 'Epilation complete homme : torse, dos, epaules et bras. Peau lisse jusqu\'a 4 semaines.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 500,
    currency: 'MAD',
    duration_minutes: 90,
    images: [SERVICE_IMAGES['smooth-homme-full']],
    rating: 4.8,
    reviews_count: 45,
    provider: { id: 14, name: 'Rachid M.' },
    isNew: true,
    status: 'active',
  },

  // === HIJAMA (category_id: 4 - Bien-etre) ===
  {
    id: 29,
    title: 'Hijama',
    slug: 'hijama',
    description: 'Seance de Hijama (cupping therapy) traditionnelle. Technique ancestrale de ventouses pour detoxifier le corps et ameliorer la circulation sanguine.',
    category_id: 4,
    category: { id: 4, name: 'Bien-etre', color: '#2A9D8F' },
    price: 300,
    currency: 'MAD',
    duration_minutes: 60,
    images: [SERVICE_IMAGES['hijama']],
    rating: 4.9,
    reviews_count: 78,
    provider: { id: 15, name: 'Youssef H.' },
    isNew: true,
    status: 'active',
  },

  // === MANUCURE (category_id: 2 - Beaute) ===
  {
    id: 30,
    title: 'Manucure Classique',
    slug: 'manucure-classique',
    description: 'Soin complet des ongles : limage, polissage, cuticules et vernis classique. Mains douces et ongles impeccables.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 150,
    currency: 'MAD',
    duration_minutes: 45,
    images: [SERVICE_IMAGES['manucure-classique']],
    rating: 4.7,
    reviews_count: 124,
    provider: { id: 16, name: 'Kenza R.' },
    status: 'active',
  },
  {
    id: 31,
    title: 'Manucure Gel / Semi-permanent',
    slug: 'manucure-gel',
    description: 'Pose de vernis gel ou semi-permanent longue tenue. Brillance et couleur jusqu\'a 3 semaines sans ecaillement.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 250,
    currency: 'MAD',
    duration_minutes: 60,
    images: [SERVICE_IMAGES['manucure-gel']],
    rating: 4.9,
    reviews_count: 89,
    provider: { id: 16, name: 'Kenza R.' },
    is_featured: true,
    status: 'active',
  },

  // === MAQUILLAGE (category_id: 2 - Beaute) ===
  {
    id: 32,
    title: 'Maquillage Jour',
    slug: 'maquillage-jour',
    description: 'Maquillage naturel et elegant pour le quotidien ou occasion speciale. Teint frais, regard sublime et levres parfaites.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 300,
    currency: 'MAD',
    duration_minutes: 45,
    images: [SERVICE_IMAGES['maquillage-jour']],
    rating: 4.8,
    reviews_count: 156,
    provider: { id: 17, name: 'Zineb A.' },
    status: 'active',
  },
  {
    id: 33,
    title: 'Maquillage Mariage',
    slug: 'maquillage-mariage',
    description: 'Maquillage de mariee professionnel avec essai inclus. Look personnalise pour votre grand jour, tenue longue duree garantie.',
    category_id: 2,
    category: { id: 2, name: 'Beaute', color: '#E63946' },
    price: 800,
    currency: 'MAD',
    duration_minutes: 90,
    images: [SERVICE_IMAGES['maquillage-mariage']],
    rating: 4.9,
    reviews_count: 67,
    provider: { id: 17, name: 'Zineb A.' },
    isNew: true,
    status: 'active',
  },
];

// Services populaires (6 premiers pour la page d'accueil)
export const POPULAR_SERVICES = SERVICES.slice(0, 6);

// Obtenir les services par categorie
export function getServicesByCategory(categoryId: number): Service[] {
  return SERVICES.filter(service => service.category_id === categoryId);
}

// Obtenir un service par ID
export function getServiceById(id: number): Service | undefined {
  return SERVICES.find(service => service.id === id);
}

// Recherche services par texte
export function searchServices(query: string): Service[] {
  const lowerQuery = query.toLowerCase();
  return SERVICES.filter(
    service =>
      service.title?.toLowerCase().includes(lowerQuery) ||
      service.description?.toLowerCase().includes(lowerQuery) ||
      service.category?.name?.toLowerCase().includes(lowerQuery)
  );
}
