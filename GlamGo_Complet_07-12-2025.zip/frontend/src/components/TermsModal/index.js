export { default } from './TermsModal';
