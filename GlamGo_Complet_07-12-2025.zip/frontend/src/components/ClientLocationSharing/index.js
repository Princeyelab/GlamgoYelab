export { default } from './ClientLocationSharing';
