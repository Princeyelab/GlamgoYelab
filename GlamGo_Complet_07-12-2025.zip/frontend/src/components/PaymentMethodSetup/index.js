export { default } from './PaymentMethodSetup';
