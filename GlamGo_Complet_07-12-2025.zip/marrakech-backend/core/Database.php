<?php

/**
 * Classe Database - Singleton pour la connexion PDO
 *
 * G�re la connexion unique � la base de donn�es MySQL
 * Utilise le pattern Singleton pour �viter les connexions multiples
 */
class Database
{
    /**
     * Instance unique de la connexion PDO
     * @var PDO|null
     */
    private static ?PDO $instance = null;

    /**
     * Configuration de la base de donn�es
     * @var array
     */
    private static array $config = [
        'host' => null,
        'dbname' => null,
        'user' => null,
        'password' => null,
        'charset' => 'utf8mb4'
    ];

    /**
     * Constructeur priv� (Singleton)
     * Emp�che l'instanciation directe de la classe
     */
    private function __construct()
    {
        // Emp�che l'instanciation
    }

    /**
     * Emp�che le clonage de l'instance
     */
    private function __clone()
    {
        // Emp�che le clonage
    }

    /**
     * Emp�che la d�s�rialisation de l'instance
     */
    public function __wakeup()
    {
        throw new Exception("Cannot unserialize singleton");
    }

    /**
     * Configure la connexion � la base de donn�es
     *
     * @param array $config Configuration avec cl�s: host, dbname, user, password
     */
    public static function configure(array $config): void
    {
        self::$config = array_merge(self::$config, $config);
    }

    /**
     * R�cup�re l'instance PDO unique (Singleton)
     *
     * @return PDO Instance PDO connect�e � la base de donn�es
     * @throws PDOException Si la connexion �choue
     */
    public static function getInstance(): PDO
    {
        if (self::$instance === null) {
            self::connect();
        }

        return self::$instance;
    }

    /**
     * Cr�e la connexion PDO � la base de donn�es
     *
     * @throws PDOException Si la connexion �choue
     */
    private static function connect(): void
    {
        // R�cup�ration de la configuration depuis les variables d'environnement
        $host = self::$config['host'] ?? getenv('DB_HOST') ?? 'mysql-db';
        $dbname = self::$config['dbname'] ?? getenv('DB_NAME') ?? 'marrakech_services';
        $user = self::$config['user'] ?? getenv('DB_USER') ?? 'marrakech_user';
        $password = self::$config['password'] ?? getenv('DB_PASSWORD') ?? 'marrakech_password';
        $charset = self::$config['charset'];

        // Construction du DSN (Data Source Name)
        $dsn = "mysql:host={$host};dbname={$dbname};charset={$charset}";

        // Options PDO pour une meilleure s�curit� et performance
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,        // Lance des exceptions en cas d'erreur
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,   // Retourne des tableaux associatifs
            PDO::ATTR_EMULATE_PREPARES => false,                // Utilise les vraies requ�tes pr�par�es
            PDO::ATTR_PERSISTENT => false,                      // Pas de connexion persistante
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$charset} COLLATE utf8mb4_unicode_ci"
        ];

        try {
            self::$instance = new PDO($dsn, $user, $password, $options);
        } catch (PDOException $e) {
            // En production, logger l'erreur sans exposer les d�tails
            error_log("Database connection failed: " . $e->getMessage());

            // En d�veloppement, afficher l'erreur
            if (getenv('APP_DEBUG') === 'true') {
                throw new PDOException("Database connection error: " . $e->getMessage());
            } else {
                throw new PDOException("Database connection error. Please check logs.");
            }
        }
    }

    /**
     * Teste la connexion � la base de donn�es
     *
     * @return bool True si la connexion fonctionne
     */
    public static function testConnection(): bool
    {
        try {
            $pdo = self::getInstance();
            $pdo->query('SELECT 1');
            return true;
        } catch (PDOException $e) {
            error_log("Database connection test failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Ferme la connexion � la base de donn�es
     * Utile pour les tests ou les scripts CLI
     */
    public static function closeConnection(): void
    {
        self::$instance = null;
    }

    /**
     * Ex�cute une requ�te SQL et retourne le statement
     * M�thode helper pour simplifier les requ�tes
     *
     * @param string $sql Requ�te SQL
     * @param array $params Param�tres de la requ�te pr�par�e
     * @return PDOStatement
     */
    public static function query(string $sql, array $params = []): PDOStatement
    {
        $pdo = self::getInstance();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /**
     * Commence une transaction
     *
     * @return bool
     */
    public static function beginTransaction(): bool
    {
        return self::getInstance()->beginTransaction();
    }

    /**
     * Valide une transaction
     *
     * @return bool
     */
    public static function commit(): bool
    {
        return self::getInstance()->commit();
    }

    /**
     * Annule une transaction
     *
     * @return bool
     */
    public static function rollBack(): bool
    {
        return self::getInstance()->rollBack();
    }

    /**
     * Retourne l'ID du dernier enregistrement ins�r�
     *
     * @return string
     */
    public static function lastInsertId(): string
    {
        return self::getInstance()->lastInsertId();
    }
}
