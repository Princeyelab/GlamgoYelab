<?php

/**
 * Classe Model - Classe de base pour tous les mod�les
 *
 * Fournit des m�thodes CRUD de base pour interagir avec la base de donn�es
 */
abstract class Model
{
    /**
     * Instance PDO
     * @var PDO
     */
    protected PDO $db;

    /**
     * Nom de la table dans la base de donn�es
     * Doit �tre d�fini dans les classes enfants
     * @var string
     */
    protected string $table;

    /**
     * Cl� primaire de la table (par d�faut 'id')
     * @var string
     */
    protected string $primaryKey = 'id';

    /**
     * Constructeur
     * Initialise la connexion � la base de donn�es
     */
    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * R�cup�re tous les enregistrements de la table
     *
     * @return array
     */
    public function all(): array
    {
        $stmt = $this->db->query("SELECT * FROM {$this->table}");
        return $stmt->fetchAll();
    }

    /**
     * R�cup�re un enregistrement par son ID
     *
     * @param int $id ID de l'enregistrement
     * @return array|null
     */
    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ?");
        $stmt->execute([$id]);
        $result = $stmt->fetch();

        return $result ?: null;
    }

    /**
     * R�cup�re un enregistrement selon une condition
     *
     * @param string $column Nom de la colonne
     * @param mixed $value Valeur recherch�e
     * @return array|null
     */
    public function findBy(string $column, $value): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE {$column} = ?");
        $stmt->execute([$value]);
        $result = $stmt->fetch();

        return $result ?: null;
    }

    /**
     * R�cup�re plusieurs enregistrements selon une condition
     *
     * @param string $column Nom de la colonne
     * @param mixed $value Valeur recherch�e
     * @return array
     */
    public function where(string $column, $value): array
    {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE {$column} = ?");
        $stmt->execute([$value]);
        return $stmt->fetchAll();
    }

    /**
     * Cr�e un nouvel enregistrement
     *
     * @param array $data Donn�es � ins�rer (colonne => valeur)
     * @return int ID de l'enregistrement cr��
     */
    public function create(array $data): int
    {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));

        $sql = "INSERT INTO {$this->table} ({$columns}) VALUES ({$placeholders})";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(array_values($data));

        return (int)$this->db->lastInsertId();
    }

    /**
     * Met � jour un enregistrement
     *
     * @param int $id ID de l'enregistrement
     * @param array $data Donn�es � mettre � jour (colonne => valeur)
     * @return bool
     */
    public function update(int $id, array $data): bool
    {
        $setParts = [];
        foreach (array_keys($data) as $column) {
            $setParts[] = "{$column} = ?";
        }
        $setClause = implode(', ', $setParts);

        $sql = "UPDATE {$this->table} SET {$setClause} WHERE {$this->primaryKey} = ?";
        $stmt = $this->db->prepare($sql);

        $values = array_values($data);
        $values[] = $id;

        return $stmt->execute($values);
    }

    /**
     * Supprime un enregistrement
     *
     * @param int $id ID de l'enregistrement
     * @return bool
     */
    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE {$this->primaryKey} = ?");
        return $stmt->execute([$id]);
    }

    /**
     * Compte le nombre d'enregistrements
     *
     * @param string|null $column Colonne pour la condition WHERE (optionnel)
     * @param mixed $value Valeur pour la condition WHERE (optionnel)
     * @return int
     */
    public function count(?string $column = null, $value = null): int
    {
        if ($column && $value) {
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM {$this->table} WHERE {$column} = ?");
            $stmt->execute([$value]);
        } else {
            $stmt = $this->db->query("SELECT COUNT(*) FROM {$this->table}");
        }

        return (int)$stmt->fetchColumn();
    }

    /**
     * Ex�cute une requ�te SQL personnalis�e et retourne les r�sultats
     *
     * @param string $sql Requ�te SQL
     * @param array $params Param�tres de la requ�te pr�par�e
     * @return array
     */
    public function query(string $sql, array $params = []): array
    {
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Ex�cute une requ�te SQL personnalis�e sans retour
     *
     * @param string $sql Requ�te SQL
     * @param array $params Param�tres de la requ�te pr�par�e
     * @return bool
     */
    public function execute(string $sql, array $params = []): bool
    {
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * Pagine les r�sultats
     *
     * @param int $page Num�ro de la page (commence � 1)
     * @param int $perPage Nombre d'�l�ments par page
     * @return array
     */
    public function paginate(int $page = 1, int $perPage = 10): array
    {
        $offset = ($page - 1) * $perPage;

        $stmt = $this->db->prepare("SELECT * FROM {$this->table} LIMIT ? OFFSET ?");
        $stmt->execute([$perPage, $offset]);

        return [
            'data' => $stmt->fetchAll(),
            'page' => $page,
            'per_page' => $perPage,
            'total' => $this->count()
        ];
    }
}
