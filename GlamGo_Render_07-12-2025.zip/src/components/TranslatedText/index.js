export { default, useTranslatedAttr } from './TranslatedText';
