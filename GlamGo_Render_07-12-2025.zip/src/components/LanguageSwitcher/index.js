export { default } from './LanguageSwitcher';
export { default as LanguageSwitcher } from './LanguageSwitcher';
