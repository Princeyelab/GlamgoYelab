export { default } from './EmergencyButtonProvider';
