export { default } from './Price';
